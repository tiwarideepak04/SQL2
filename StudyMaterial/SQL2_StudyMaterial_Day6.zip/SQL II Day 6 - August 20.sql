use temp;
create table person(
adhaarno int(12) primary key,
pname varchar(40) not null,
mobile varchar(10) unique,
income float(9,2) default 0,
age int check(age>18));

desc person;

insert into person values
(1234567890,'Deepali',2222222,12000,40);
#error - duplicate primary ke
insert into person values
(1234567890,'Deepali',2222222,12000,40);
## error -- null primary key
insert into person values
(null,'Deepali',2222222,12000,40);
## duplicate mobile no
insert into person values
(1234567891,'Deepali',2222222,12000,40);
## successful
insert into person values
(1234567891,'Deepali',2222221,12000,40);
## error - null value for name
insert into person values
(1234567892,null,2222223,12000,40);
# successful
insert into person values
(1234567892,'Deepa',2222223,null,40);

select * from person;
# successful -- income should take default value 0
insert into person(adhaarno,pname) values
(12345678,'Deeps');

select * from person;
## Error - age<18
insert into person values
(1234567893,'Deepa',2222224,1234,4);

## check(city in ('Pune', 'Mumbai', 'Benglore', 'Chennai'))

 
create table club_members(
mid int,
adhaarno int(12),
mname varchar(40),
mtype varchar(20),
constraint club_member_chk check(mtype in ('Lifetime','Golden','Silver')),
constraint club_members_pk primary key(mid),
constraint club_members_fk foreign key(adhaarno) references person(adhaarno));

desc club_members;
select * from person;
insert into club_members values(1,12345678,'Deepali G', 'Silver'); ## Successfull
insert into club_members values(2,12345677,'Deepali', 'Silver');

update person set adhaarno = 1234566 where adhaarno = 1234567890;
update person set pname = 'Deepa' where adhaarno = 12345678;

delete from person where adhaarno = 1234567800;

alter table club_members drop primary key;
desc club_members;
alter table club_members add primary key(mid);

alter table club_members drop foreign key club_members_fk;

alter table club_members add foreign key(adhaarno) references 
person(adhaarno) on update cascade;

update person set adhaarno = 1234567800 where adhaarno = 12345678;

select * from person;
select * from club_members;

alter table club_members drop foreign key club_members_ibfk_1;

alter table club_members add foreign key(adhaarno) references 
person(adhaarno) on update cascade on delete cascade;

SELECT CONSTRAINT_NAME,
       UNIQUE_CONSTRAINT_NAME, 
       MATCH_OPTION, 
       UPDATE_RULE,
       DELETE_RULE,
       TABLE_NAME,
       REFERENCED_TABLE_NAME
FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = 'Temp';

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 1. Create a table Airline_Details. Follow the instructions given below: 
-- -- Q1. Values in the columns Flight_ID should not be null.
-- -- Q2. Each name of the airline should be unique.
-- -- Q3. No country other than United Kingdom, USA, India, Canada and Singapore should be accepted
-- -- Q4. Assign primary key to Flight_ID
-- ---------------------------------------------------------------------------------------------------------------------------------------------------

-- -----------------------------------------------------
-- Table Airline_Details
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Airline_Details (
  Flight_ID INT NOT NULL,
  Airline VARCHAR(100) NULL UNIQUE,
  Country VARCHAR(50) NULL CHECK (Country IN ('United Kingdom', 'USA', 'India', 'Canada', 'Singapore')),
  Punctuality FLOAT NULL,
  Service_Quality FLOAT NULL,
  AirHelp_Score FLOAT NULL,
  PRIMARY KEY (Flight_ID)
);

SELECT * FROM Airline_Details;
desc airline_details;
-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 2. Create a table Passengers. Follow the instructions given below: 
-- -- Q1. Values in the columns Traveller_ID and PNR should not be null.
-- -- Q2. Only passengers having age greater than 18 are allowed.
-- -- Q3. Assign primary key to Traveller_ID
-- ---------------------------------------------------------------------------------------------------------------------------------------------------

-- -----------------------------------------------------
-- Table Passengers
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Passengers (
  Traveller_ID VARCHAR(5) NOT NULL,
  Name VARCHAR(50) NULL,
  PNR VARCHAR(10) NOT NULL,
  Flight_ID INT NULL,
  Ticket_Price INT NULL,
  age int check (age>18),
  PRIMARY KEY (Traveller_ID)
);
desc passengers;
SELECT * FROM PASSENGERS;

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- Questions for table Passengers:  
-- -- Q3. PNR status should be unique and should not be null.
-- -- Q4. Flight Id should not be null.
-- ---------------------------------------------------------------------------------------------------------------------------------------------------

# 3.
ALTER TABLE Passengers MODIFY PNR VARCHAR(10) NOT NULL UNIQUE;
# 4.
ALTER TABLE Passengers MODIFY Flight_ID INT NOT NULL;


-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 5. Create a table Senior_Citizen_Details. Follow the instructions given below: 
-- -- Q1. Column Traveller_ID should not contain any null value.
-- -- Q2. Assign primary key to Traveller_ID
-- -- Q3. Assign foreign key constraint on Traveller_ID such that if any row from passenger table is updated, then the Senior_Citizen_Details table should also get updated.
-- -- --  Also deletion of any row from passenger table should not be allowed.
-- ---------------------------------------------------------------------------------------------------------------------------------------------------

-- -----------------------------------------------------
-- Table Senior_Citizen_Details
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Senior_Citizen_Details (
  Traveller_ID VARCHAR(5) NOT NULL,
  Senior_Citizen VARCHAR(5) NULL,
  Discounted_Price VARCHAR(20) NULL,
  PRIMARY KEY (Traveller_ID),
  CONSTRAINT fk_Passenger_Senior_Citizen
    FOREIGN KEY (Traveller_ID)
    REFERENCES Passengers(Traveller_ID)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);

SELECT * FROM SENIOR_CITIZEN_details;
SELECT CONSTRAINT_NAME,
       UNIQUE_CONSTRAINT_NAME, 
       MATCH_OPTION, 
       UPDATE_RULE,
       DELETE_RULE,
       TABLE_NAME,
       REFERENCED_TABLE_NAME
FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = 'InClass';
-- --------------------------------------------------------------------------------------------------------------------------------------------------- 
-- -- Q6. Create a new column Age in Passengers table that takes values greater than 18. 

-- -- Note: Airlines service is providing a 10% discount on ticket price.
-- -- 
-- ---------------------------------------------------------------------------------------------------------------------------------------------------

# 6 *****************************************************************************
## Need not to execute - Age is already a column in the table
ALTER TABLE Passengers
	ADD COLUMN Age INT CHECK (AGE > 18);
    
-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 7. Create a table books. Follow the instructions given below: 
-- -- Columns: books_no, description, author_name, cost
-- -- Qa. The cost should not be less than or equal to 0.
-- -- Qb. The cost column should not be null.
-- -- Qc. Assign a primary key to the column books_no.
-- ---------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE books (
    books_no VARCHAR(18) PRIMARY KEY,
    description VARCHAR(250),
    author VARCHAR(250),
    cost DECIMAL(10, 2) NOT NULL 
    CHECK (cost > 0));


# Q8. Update the table 'books' such that the values in the columns 'description' and author' must be unique.
ALTER TABLE books
ADD CONSTRAINT new_desc1
UNIQUE (description, author);

## Alternate solution
alter table books
modify description varchar(250) unique, modify author_name varchar(250) unique;


-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 9. Create a table bike_sales. Follow the instructions given below: 
-- -- Columns: id, product, quantity, release_year, release_month
-- -- Q1. Assign a primary key to ID. Also the id should auto increment.
-- -- Q2. None of the columns should be left null.
-- -- Q3. The release_month should be between 1 and 12 (including the boundries i.e. 1 and 12).
-- -- Q4. The release_year should be between 2000 and 2010.
-- -- Q5. The quantity should be greater than 0.
-- ---------------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE bike_sales (
id INT AUTO_INCREMENT,
product VARCHAR(100) NOT NULL,
quantity INT NOT NULL,
release_year INT NOT NULL,
release_month INT NOT NULL,
CHECK (release_month >=1 AND release_month <=12 ),
CHECK (release_year BETWEEN 2000 AND 2010),
CHECK (quantity > 0),
PRIMARY KEY(id));

-- --------------------------------------------------------------------------
-- Use the following comands to insert the values in the table bike_sales
INSERT INTO bike_sales VALUES('1','Pulsar','1','2001','7');
INSERT INTO bike_sales VALUES('2','yamaha','3','2002','3');
INSERT INTO bike_sales VALUES('3','Splender','2','2004','5');
INSERT INTO bike_sales VALUES('4','KTM','2','2003','1');
INSERT INTO bike_sales VALUES('5','Hero','1','2005','9');
INSERT INTO bike_sales VALUES('6','Royal Enfield','2','2001','3');
INSERT INTO bike_sales VALUES('7','Bullet','1','2005','7');
INSERT INTO bike_sales VALUES('8','Revolt RV400','2','2010','7');
INSERT INTO bike_sales VALUES('9','Jawa 42','1','2010','5');
-- --------------------------------------------------------------------------
SELECT * FROM BIKE_SALES;
insert into bike_sales(product, quantity, release_year, release_month) 
values ('Honda', '5', '2005','6');

select * from bike_sales;